import EmailSubscribe from '../EmailSubscribe';

export default function EmailSubscribeExample() {
  return (
    <div className="p-8 bg-black">
      <EmailSubscribe />
    </div>
  );
}
