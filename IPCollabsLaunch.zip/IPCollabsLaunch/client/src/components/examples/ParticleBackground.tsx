import ParticleBackground from '../ParticleBackground';

export default function ParticleBackgroundExample() {
  return (
    <div className="relative w-full h-64 bg-black">
      <ParticleBackground />
    </div>
  );
}
