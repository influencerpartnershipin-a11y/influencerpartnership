import SocialLinks from '../SocialLinks';

export default function SocialLinksExample() {
  return (
    <div className="p-8 bg-black">
      <SocialLinks />
    </div>
  );
}
