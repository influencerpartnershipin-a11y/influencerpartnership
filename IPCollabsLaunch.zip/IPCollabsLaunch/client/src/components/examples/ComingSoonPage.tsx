import ComingSoonPage from '../ComingSoonPage';

export default function ComingSoonPageExample() {
  return <ComingSoonPage />;
}
