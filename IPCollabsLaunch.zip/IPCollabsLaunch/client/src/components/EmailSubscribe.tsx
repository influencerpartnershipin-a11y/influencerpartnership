import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';

export default function EmailSubscribe() {
  const [email, setEmail] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email || !email.includes('@')) {
      toast({
        title: "Invalid Email",
        description: "Please enter a valid email address.",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    
    setTimeout(() => {
      setIsLoading(false);
      toast({
        title: "Success!",
        description: "You've been added to our waitlist. We'll notify you when we launch!",
      });
      setEmail('');
    }, 1000);
  };

  return (
    <form onSubmit={handleSubmit} className="w-full max-w-lg mx-auto">
      <div className="flex flex-col sm:flex-row gap-4 p-2 rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10 shadow-2xl">
        <Input
          type="email"
          placeholder="Enter your email address"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="flex-1 bg-transparent border-0 text-foreground placeholder:text-muted-foreground/60 focus:ring-0 focus-visible:ring-0 text-base sm:text-lg h-12 sm:h-14 px-4"
          data-testid="input-email"
        />
        <Button
          type="submit"
          disabled={isLoading}
          className="bg-gradient-to-r from-primary via-yellow-500 to-primary text-primary-foreground font-bold px-8 sm:px-10 h-12 sm:h-14 text-base sm:text-lg rounded-xl transition-all duration-300 hover:scale-105 hover:shadow-2xl hover:shadow-primary/60 relative overflow-hidden group"
          data-testid="button-notify"
        >
          <span className="absolute inset-0 bg-gradient-to-r from-yellow-400 to-primary opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          <span className="relative z-10">{isLoading ? 'Subscribing...' : 'Notify Me'}</span>
        </Button>
      </div>
    </form>
  );
}
