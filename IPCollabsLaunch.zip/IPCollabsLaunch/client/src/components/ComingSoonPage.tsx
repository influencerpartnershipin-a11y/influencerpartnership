import { useEffect, useState } from 'react';
import ParticleBackground from './ParticleBackground';
import EmailSubscribe from './EmailSubscribe';
import SocialLinks from './SocialLinks';
import logoImage from '@assets/png logo1_1759781065557.png';

export default function ComingSoonPage() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  return (
    <div className="relative min-h-screen w-full overflow-hidden bg-black flex items-center justify-center p-4">
      <div 
        className="absolute inset-0"
        style={{
          background: 'radial-gradient(circle at 20% 50%, rgba(234, 179, 8, 0.15) 0%, transparent 50%), radial-gradient(circle at 80% 50%, rgba(168, 85, 247, 0.1) 0%, transparent 50%)',
        }}
      />
      
      <div 
        className="absolute top-20 left-10 w-72 h-72 bg-primary/20 rounded-full blur-[120px] animate-pulse"
        style={{ animationDuration: '4s' }}
      />
      <div 
        className="absolute bottom-20 right-10 w-96 h-96 bg-purple-500/10 rounded-full blur-[120px] animate-pulse"
        style={{ animationDuration: '6s', animationDelay: '1s' }}
      />

      <ParticleBackground />

      <div className="relative z-10 w-full max-w-5xl mx-auto text-center space-y-16 px-4">
        <div 
          className={`transition-all duration-1000 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
          style={{ transitionDelay: '200ms' }}
        >
          <div className="relative inline-block">
            <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-purple-500/20 blur-3xl rounded-full" />
            <img
              src={logoImage}
              alt="IPCollabs Logo"
              className="relative w-56 sm:w-72 md:w-96 mx-auto mb-6 drop-shadow-2xl hover:scale-105 transition-transform duration-500"
              data-testid="img-logo"
            />
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-foreground mb-3 tracking-tight" data-testid="text-brand-name">
            IPCollabs
          </h2>
          <p className="text-sm sm:text-base text-primary/80 italic font-light tracking-wide" data-testid="text-privacy-slogan">
            We respect your privacy
          </p>
        </div>

        <div
          className={`space-y-6 transition-all duration-1000 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
          style={{ transitionDelay: '500ms' }}
        >
          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold text-foreground leading-tight tracking-tight">
            Building the Future of
          </h1>
          <div className="relative inline-block">
            <div className="absolute inset-0 bg-gradient-to-r from-primary/30 to-yellow-500/30 blur-2xl" />
            <h1 className="relative text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold leading-tight bg-gradient-to-r from-primary via-yellow-400 to-primary bg-clip-text text-transparent animate-pulse" style={{ animationDuration: '3s' }}>
              Brand–Influencer Collaboration
            </h1>
          </div>
        </div>

        <div
          className={`transition-all duration-1000 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
          style={{ transitionDelay: '800ms' }}
        >
          <div className="inline-block px-6 py-3 rounded-full bg-primary/10 border border-primary/20 backdrop-blur-sm">
            <p className="text-xl sm:text-2xl md:text-3xl font-semibold text-foreground tracking-wide" data-testid="text-coming-soon">
              Website Coming Soon
            </p>
          </div>
        </div>

        <div
          className={`transition-all duration-1000 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
          style={{ transitionDelay: '1100ms' }}
        >
          <EmailSubscribe />
        </div>

        <div
          className={`transition-all duration-1000 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
          style={{ transitionDelay: '1400ms' }}
        >
          <SocialLinks />
        </div>

        <div
          className={`pt-4 space-y-3 transition-all duration-1000 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
          style={{ transitionDelay: '1600ms' }}
        >
          <div className="inline-block px-8 py-4 rounded-2xl bg-white/5 backdrop-blur-md border border-white/10">
            <div className="space-y-2">
              <p className="text-sm sm:text-base text-muted-foreground flex items-center justify-center gap-2" data-testid="text-email-contact">
                <Mail className="w-4 h-4 text-primary" />
                <span className="text-foreground/80">ipcollabs@influencerpartnership.shop</span>
              </p>
              <p className="text-sm sm:text-base text-muted-foreground flex items-center justify-center gap-2" data-testid="text-instagram-contact">
                <Instagram className="w-4 h-4 text-primary" />
                <span className="text-foreground/80">@influencer_partnership</span>
              </p>
            </div>
          </div>
        </div>
      </div>

      <div 
        className="absolute inset-0 pointer-events-none opacity-30"
        style={{
          background: 'linear-gradient(135deg, transparent 0%, rgba(234, 179, 8, 0.05) 50%, transparent 100%)',
          animation: 'shimmer 25s linear infinite',
          zIndex: 2,
        }}
      />

      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/50 to-transparent" />
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/50 to-transparent" />

      <style>{`
        @keyframes shimmer {
          0% {
            transform: translateX(-100%) translateY(-100%) rotate(0deg);
          }
          100% {
            transform: translateX(100%) translateY(100%) rotate(360deg);
          }
        }
      `}</style>
    </div>
  );
}

function Mail({ className }: { className?: string }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <rect width="20" height="16" x="2" y="4" rx="2" />
      <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" />
    </svg>
  );
}

function Instagram({ className }: { className?: string }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <rect width="20" height="20" x="2" y="2" rx="5" ry="5" />
      <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
      <line x1="17.5" x2="17.51" y1="6.5" y2="6.5" />
    </svg>
  );
}
