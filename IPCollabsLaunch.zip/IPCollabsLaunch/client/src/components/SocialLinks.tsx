import { Instagram, Mail, Linkedin } from 'lucide-react';

export default function SocialLinks() {
  const socials = [
    {
      icon: Instagram,
      href: 'https://instagram.com/influencer_partnership',
      label: 'Instagram',
      testId: 'link-instagram'
    },
    {
      icon: Mail,
      href: 'mailto:ipcollabs@influencerpartnership.shop',
      label: 'Email',
      testId: 'link-email'
    },
    {
      icon: Linkedin,
      href: 'https://linkedin.com',
      label: 'LinkedIn',
      testId: 'link-linkedin'
    },
  ];

  return (
    <div className="flex gap-6 justify-center">
      {socials.map((social) => (
        <a
          key={social.label}
          href={social.href}
          target="_blank"
          rel="noopener noreferrer"
          className="relative w-14 h-14 rounded-2xl bg-white/5 backdrop-blur-sm border border-white/10 flex items-center justify-center text-muted-foreground hover:text-primary hover:border-primary hover:bg-primary/10 transition-all duration-300 hover:scale-110 hover:-translate-y-1 group"
          aria-label={social.label}
          data-testid={social.testId}
        >
          <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-primary/0 to-primary/0 group-hover:from-primary/20 group-hover:to-yellow-500/20 transition-all duration-300" />
          <social.icon className="w-6 h-6 relative z-10" />
        </a>
      ))}
    </div>
  );
}
