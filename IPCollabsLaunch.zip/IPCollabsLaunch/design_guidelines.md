# Design Guidelines for IPCollabs Coming Soon Landing Page

## Design Approach
**Reference-Based Approach**: Premium tech startup aesthetic inspired by modern SaaS landing pages (Stripe, Linear, Vercel) with luxury brand elements for sophisticated brand-influencer platform positioning.

## Core Design Principles
- Premium minimalism with strategic gold accents
- Futuristic professionalism through subtle animations
- Dark-first design creating sophisticated, exclusive atmosphere
- Single-page focused experience driving email capture

## Color Palette

### Dark Mode (Primary)
- **Background Gradient**: Deep black (0 0% 0%) transitioning to dark charcoal (0 0% 8%)
- **Gold Highlights**: Rich gold (45 85% 55%) for premium accents and glows
- **Text Colors**:
  - Primary headings: Pure white (0 0% 100%)
  - Body text: Soft gray (0 0% 85%)
  - Accent text: Gold (45 85% 55%)
- **Interactive Elements**:
  - Input borders: Dark gray (0 0% 20%) with gold glow on focus
  - Button primary: Gold gradient (45 90% 50% to 40 85% 45%)
  - Button hover: Brightened gold (45 90% 60%)

## Typography

### Font Families
- **Primary**: Poppins (via Google Fonts)
  - Headings: 600-700 weight
  - Body: 400-500 weight
- **Alternative**: Montserrat for contrast if needed

### Type Scale
- **Logo Area**: Large, prominent positioning
- **Main Tagline**: text-2xl to text-4xl (responsive), font-semibold
- **"Website Coming Soon"**: text-xl to text-2xl, font-medium
- **Email Input**: text-base, clean and readable
- **Footer Contact**: text-sm, elegant

## Layout System

### Spacing Primitives
Tailwind units: **4, 8, 12, 16, 24** (p-4, p-8, p-12, etc.)
- Section padding: py-16 to py-24
- Element spacing: gap-8 to gap-12
- Micro-spacing: p-4, m-2

### Viewport Strategy
- Single viewport (100vh) centered experience
- All content visible without scrolling (true "Coming Soon" format)
- Vertical centering with flex column layout

## Component Library

### Hero/Center Section
- **Logo Container**: max-w-md, centered, mb-12
- **Tagline**: Centered text, mb-8, fade-in animation (0.6s delay)
- **Coming Soon Text**: Centered, mb-12, fade-in animation (0.9s delay)

### Email Subscription Form
- **Layout**: Flex row on desktop, column on mobile
- **Input Field**: 
  - Dark background (0 0% 12%)
  - Border with subtle glow effect
  - Rounded corners (rounded-lg)
  - Focus state: gold border glow
  - Placeholder: "Enter your email"
- **Submit Button**:
  - Gold gradient background
  - White text
  - Hover: Brightness increase + subtle scale
  - Text: "Notify Me"
- **Container**: max-w-md, centered, mb-16

### Social Media Icons
- **Icons**: Instagram, Email (envelope), LinkedIn
- **Style**: 
  - Circular or square with rounded corners
  - Gold on hover with glow effect
  - Default: white/gray with opacity
  - Size: w-12 h-12 or similar
  - Spacing: gap-6
- **Layout**: Horizontal flex row, centered, mb-12

### Footer Contact Section
- **Email**: ipcollabs@influencerpartnership.shop
- **Instagram**: @influencer_partnership
- **Icons**: 📧 and 📱 emoji or icon font equivalents
- **Style**: Small, subtle, bottom-aligned
- **Color**: Muted gray with gold on hover

## Background Effects

### Gradient Implementation
- Diagonal or radial gradient from pure black to dark charcoal
- Optional: Subtle dark purple/blue tints for depth (280 20% 10%)

### Animated Particles/Shimmer
- **Particle System**:
  - 20-30 small glowing dots
  - Gold color with varying opacity (0.1 to 0.4)
  - Slow floating animation (20-40s duration)
  - Random positions across viewport
  - Blur filter for soft glow effect
- **Shimmer Effect**:
  - Subtle diagonal light sweep across background
  - Very slow (30s+) infinite animation
  - Low opacity (0.05-0.1)

## Animations

### Page Load Sequence
1. Background fade-in (0.3s)
2. Logo fade-in + scale (0.6s, starts after 0.2s)
3. Tagline fade-in (0.6s, starts after 0.5s)
4. "Coming Soon" fade-in (0.6s, starts after 0.8s)
5. Email form fade-in + slide up (0.6s, starts after 1.1s)
6. Social icons fade-in (0.6s, starts after 1.4s)
7. Footer fade-in (0.6s, starts after 1.6s)

### Interactive Animations
- Input focus: Border glow transition (0.3s)
- Button hover: Scale 1.05, brightness increase (0.2s)
- Social icon hover: Color to gold + glow (0.3s)
- Particles: Continuous slow float animation

### Glow Effects
- Gold glow: box-shadow with gold color, blur radius 20-30px
- Apply to: focused inputs, hovered buttons, particles
- Intensity: Low to medium for premium, not overwhelming

## Responsive Behavior

### Desktop (lg+)
- All content centered vertically and horizontally
- Email form: horizontal layout (input + button side-by-side)
- Max-width constraints prevent over-stretching

### Tablet (md)
- Slightly reduced font sizes
- Maintained centered layout
- Email form: may stack or stay horizontal depending on space

### Mobile (base)
- Email form: Vertical stack (input full-width, button below)
- Reduced spacing (py-12 instead of py-24)
- Logo max-w-xs instead of max-w-md
- Social icons remain horizontal but smaller (w-10 h-10)

## Asset Requirements

### Images
- **Logo**: Provided PNG logo (png logo1_1759781065557.png)
- **Placement**: Top-center of page, prominent display
- **Size**: Responsive max-width (max-w-xs on mobile, max-w-md on desktop)

### Icons
- **Library**: Font Awesome via CDN
- **Specific Icons**:
  - Instagram: fa-instagram
  - Email: fa-envelope
  - LinkedIn: fa-linkedin
- **Style**: Solid or brands depending on icon

### Fonts
- **Google Fonts**: Poppins (weights: 400, 500, 600, 700)

## Quality Standards
- Smooth, professional animations with no jank
- Perfect centering on all viewport sizes
- Consistent gold accent usage (not overdone)
- Premium feel through restraint and polish
- Email validation for subscription form
- Accessible focus states and color contrast