// Particle Animation
class ParticleSystem {
    constructor() {
        this.canvas = document.getElementById('particleCanvas');
        this.ctx = this.canvas.getContext('2d');
        this.particles = [];
        this.particleCount = 80;
        
        this.init();
    }
    
    init() {
        this.resizeCanvas();
        window.addEventListener('resize', () => this.resizeCanvas());
        
        // Create particles
        for (let i = 0; i < this.particleCount; i++) {
            this.particles.push({
                x: Math.random() * this.canvas.width,
                y: Math.random() * this.canvas.height,
                size: Math.random() * 2.5 + 0.5,
                speedX: (Math.random() - 0.5) * 0.3,
                speedY: (Math.random() - 0.5) * 0.3,
                opacity: Math.random() * 0.4 + 0.1
            });
        }
        
        this.animate();
    }
    
    resizeCanvas() {
        this.canvas.width = window.innerWidth;
        this.canvas.height = window.innerHeight;
    }
    
    animate() {
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        
        this.particles.forEach(particle => {
            particle.x += particle.speedX;
            particle.y += particle.speedY;
            
            // Bounce off walls
            if (particle.x < 0 || particle.x > this.canvas.width) particle.speedX *= -1;
            if (particle.y < 0 || particle.y > this.canvas.height) particle.speedY *= -1;
            
            // Create gradient
            const gradient = this.ctx.createRadialGradient(
                particle.x, particle.y, 0,
                particle.x, particle.y, particle.size * 2
            );
            gradient.addColorStop(0, `rgba(234, 179, 8, ${particle.opacity})`);
            gradient.addColorStop(0.5, `rgba(250, 204, 21, ${particle.opacity * 0.5})`);
            gradient.addColorStop(1, 'rgba(234, 179, 8, 0)');
            
            // Draw particle
            this.ctx.beginPath();
            this.ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
            this.ctx.fillStyle = gradient;
            this.ctx.shadowBlur = 15;
            this.ctx.shadowColor = `rgba(234, 179, 8, ${particle.opacity * 0.8})`;
            this.ctx.fill();
        });
        
        requestAnimationFrame(() => this.animate());
    }
}

// Email Form Handler
class EmailForm {
    constructor() {
        this.form = document.getElementById('emailForm');
        this.input = document.getElementById('emailInput');
        this.button = document.getElementById('submitButton');
        this.buttonText = this.button.querySelector('.button-text');
        
        this.init();
    }
    
    init() {
        this.form.addEventListener('submit', (e) => this.handleSubmit(e));
    }
    
    async handleSubmit(e) {
        e.preventDefault();
        
        const email = this.input.value.trim();
        
        if (!email || !this.isValidEmail(email)) {
            this.showToast('Invalid Email', 'Please enter a valid email address.', 'error');
            return;
        }
        
        // Disable button
        this.button.disabled = true;
        this.buttonText.textContent = 'Subscribing...';
        
        // Simulate API call
        setTimeout(() => {
            this.button.disabled = false;
            this.buttonText.textContent = 'Notify Me';
            this.input.value = '';
            this.showToast('Success!', "You've been added to our waitlist. We'll notify you when we launch!", 'success');
        }, 1000);
    }
    
    isValidEmail(email) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    }
    
    showToast(title, message, type) {
        const toast = document.getElementById('toast');
        const toastTitle = toast.querySelector('.toast-title');
        const toastMessage = toast.querySelector('.toast-message');
        
        toastTitle.textContent = title;
        toastMessage.textContent = message;
        
        // Add error styling if needed
        if (type === 'error') {
            toast.style.borderColor = 'rgba(239, 68, 68, 0.5)';
            toastTitle.style.color = '#ef4444';
        } else {
            toast.style.borderColor = 'rgba(234, 179, 8, 0.3)';
            toastTitle.style.color = '#eab308';
        }
        
        // Show toast
        toast.classList.add('show');
        
        // Hide after 4 seconds
        setTimeout(() => {
            toast.classList.remove('show');
        }, 4000);
    }
}

// Initialize on DOM load
document.addEventListener('DOMContentLoaded', () => {
    new ParticleSystem();
    new EmailForm();
});
